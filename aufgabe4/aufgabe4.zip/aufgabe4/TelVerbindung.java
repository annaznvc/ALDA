package aufgabe4;

public record TelVerbindung(TelKnoten u, TelKnoten v, int c) {
}
