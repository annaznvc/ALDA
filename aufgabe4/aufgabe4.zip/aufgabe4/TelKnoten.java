package aufgabe4;

public record TelKnoten(int x, int y) {
}
